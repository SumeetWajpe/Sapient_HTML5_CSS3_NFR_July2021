// no access to document (DOM)
// access to XMLHttpRequest
// console.log(document); // Error !
// console.log(XMLHttpRequest);
// console.log(window); // Error !

onmessage = function (msgFromMainThread) {
  console.log("Received from Main Thread : " + msgFromMainThread.data);
  let largeArray = [];
  for (let i = 0; i < 5000; i++) {
    largeArray[i] = [];
    for (let j = 0; j < 5000; j++) {
      largeArray[i][j] = Math.random();
    }
  }

  //   console.log(largeArray[2000][2000]);
  postMessage(largeArray[2000][2000]); // send data to main Thread (script)
};
